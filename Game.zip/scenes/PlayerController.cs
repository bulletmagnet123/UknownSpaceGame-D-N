using Godot;
using System;
using BulletmagnetAndIzendaleGameProject.scenes;

public partial class PlayerController : CharacterBody2D
{
	[Export]
	public float Speed { get; set; } = 500;
	
	[Export]
	public Collider collider;

	Asteroid asteroid;

	[Export]
	public int Health { get; set; } = 10;

	public override void _Ready()
	{
		AddToGroup("Player");
	}

	public void TakeDamage(int damage)
	{
		Health -= damage;
		if (Health <= 0)
		{
			Die();
		}
	}
	
	public void Die()
	{
		QueueFree();
	}

	public override void _PhysicsProcess(double delta)
	{
		var speed = 500;
		var velocity = Vector2.Zero;
		var direction = new Vector2(
			Input.GetActionStrength("RIGHT") - Input.GetActionStrength("LEFT"),
			Input.GetActionStrength("DOWN") - Input.GetActionStrength("UP")
		);
		
		if (direction.Length() > 1.0f)
		{
		 	direction = direction.Normalized();
		}
		
		Velocity = direction * Speed;
		MoveAndSlide();

		for (int collisionIndex = 0; collisionIndex < GetSlideCollisionCount(); collisionIndex++)
		{
			var collision = GetSlideCollision(collisionIndex);
			if (collision.GetCollider() is Asteroid asteroid)
			{
				Vector2 pushDirection = -collision.GetNormal();
				asteroid.ApplyCentralImpulse(pushDirection * Speed * 0.25f);
				Health -= asteroid.Health;
				if (Health <= 0)
				{
					Die();
					return;
				}
			}

			if (collision.GetCollider() is EnemyLaser)
			{
				TakeDamage(1);
			}
		}
		
		if (Input.IsActionPressed("RIGHT"))
		{
			velocity.X += speed;
		}
		if (Input.IsActionPressed("LEFT"))
		{
			velocity.X -= speed;
		}
		if (Input.IsActionPressed("DOWN"))
		{
			velocity.Y += speed;
		}
		if (Input.IsActionPressed("UP"))
		{
			velocity.Y -= speed;
		}
		var mousePosition = GetGlobalMousePosition();
		var directionToMouse = mousePosition - GlobalPosition;

		if (directionToMouse.Length() > 0)
		{
			LookAt(mousePosition);
		}
	}
}
