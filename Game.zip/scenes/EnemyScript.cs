using Godot;
using System;
using BulletmagnetAndIzendaleGameProject.scenes;

public partial class EnemyScript : Node2D
{
	[Export]
	public float Speed { get; set; } = 100f;

	public Vector2 Velocity { get; set; } = Vector2.Zero;

	private PlayerController _player;
	private EnemyLaser _enemyLaser;

	public int Health { get; set; } = 100;

	public enum MovementSatesAnimationEnemy
	{
		idle,
		move,
		shoot
	}

	public override void _Ready()
	{
		_enemyLaser = GetNodeOrNull<EnemyLaser>("EnemyLasser") ?? GetNodeOrNull<EnemyLaser>("EnemyLaser");
		_player = GetTree().GetFirstNodeInGroup("Player") as PlayerController;
	}

	public void TakeDamage(int damage)
	{
		Health -= damage;
		if (Health <= 0)
		{
			Die();
		}
	}

	public void takeDamage(int damage) => TakeDamage(damage);

	public void SetMovementSatesAnimationPlayer(MovementSatesAnimationEnemy state)
	{
		var animationPlayer = GetNodeOrNull<AnimationPlayer>("AnimationPlayer");
		if (animationPlayer != null)
		{
			animationPlayer.Play(state.ToString());
		}
	}

	public void MoveToPlayer(PlayerController player, double delta)
	{
		if (player == null || !IsInstanceValid(player))
		{
			Velocity = Vector2.Zero;
			return;
		}

		Vector2 direction = player.GlobalPosition - GlobalPosition;

		if (direction.LengthSquared() > 0.001f)
		{
			direction = direction.Normalized();
			Rotation = Mathf.Atan2(direction.Y, direction.X);
		}

		Velocity = direction * Speed;
	}

	public override void _Process(double delta)
	{
		if (_player == null || !IsInstanceValid(_player))
		{
			_player = GetTree().GetFirstNodeInGroup("Player") as PlayerController;
			if (_player == null || !IsInstanceValid(_player))
			{
				return;
			}
		}

		LookAt(_player.GlobalPosition);
		float distance = GlobalPosition.DistanceTo(_player.GlobalPosition);

		if (distance <= 100f)
		{
			SetMovementSatesAnimationPlayer(MovementSatesAnimationEnemy.shoot);
			_enemyLaser?.FireLaser(true);
		}
		else
		{
			SetMovementSatesAnimationPlayer(MovementSatesAnimationEnemy.move);
			_enemyLaser?.FireLaser(false);
			MoveToPlayer(_player, delta);
			GlobalPosition += Velocity * (float)delta;
		}
	}
	public void  Die()
	{
		QueueFree();
	}
}
